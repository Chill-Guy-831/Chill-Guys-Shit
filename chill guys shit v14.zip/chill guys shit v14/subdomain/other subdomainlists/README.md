For Popular-Site-Subdomains txt files credit goes to https://github.com/JamieFarrelly/Popular-Site-Subdomains
